# LP-Store Free GitHub Report System

## Files
- `dashboard.html` — authenticated dashboard
- `reports.html` — authenticated report library
- `reports/` — PDF files

## Daily workflow
1. Upload the PDF to the correct `reports/` folder in GitHub.
2. Open `reports.html`.
3. In `REPORTS`, add one new object:
```js
{
  type:"gate-entry",
  title:"Gate entry from 01.08.2026 to 31.08.2026",
  date:"31 Aug 2026",
  file:"reports/gate-entry/Gate-entry-01-08-2026-to-31-08-2026.pdf"
}
```
4. Commit the updated `reports.html`.
5. Wait for GitHub Pages to publish, then refresh the website.

Firebase Storage is NOT used by these files.
